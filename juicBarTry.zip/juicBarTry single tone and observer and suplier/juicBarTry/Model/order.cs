﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using juicBarTry;

namespace new_object
{
    class order
    {
        public int OrderId { get; set; }
        public string Date { get; set; }
        public int UserID { get; set; }
        public int total { get; set; }

        private DateTime dateTime = DateTime.UtcNow.Date;

        //private static SqlConnection connect = new SqlConnection("Data Source=.;Initial Catalog=Juice;Integrated Security=True");
        static singletone newconnection = new singletone();
        public void ADD_ord()
        {
            newconnection.connection_today();
            string query = "insert into [Order] values(@date,@UserID,@total);";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@date", dateTime);
            cmd.Parameters.AddWithValue("@UserID", Form1.userID);
            cmd.Parameters.AddWithValue("@total", 0);
            cmd.ExecuteNonQuery();
            
        }
        public void delete_ord(int ID)
        {
            newconnection.connection_today();
            string query = "DELETE FROM [Order] WHERE OrderId=@ID;";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.ExecuteNonQuery();

            
        }
        public void select_ord(int ID)
        {
            newconnection.connection_today();
            string query = "select* FROM [Order] WHERE OrderId=@ID;";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@ID", ID);

            SqlDataReader reader = cmd.ExecuteReader();

            reader.Read();
            this.Date = reader["Date"].ToString();
            this.UserID = int.Parse(reader["UserID"].ToString());
            this.OrderId = int.Parse(reader["OrderId"].ToString());
            this.total = int.Parse(reader["total"].ToString());

            
        }
        public static List<order> selectAll()
        {
            newconnection.connection_today();
            string query = "select * FROM [Order];";
            List<order> orders = new List<order>();
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                order ord = new order();
                ord.OrderId = Convert.ToInt32(reader["OrderID"]);
                ord.Date = reader["Date"].ToString();
                ord.UserID = int.Parse(reader["UserID"].ToString());
                ord.total = Convert.ToInt32(reader["total"]);

                orders.Add(ord);
            }
            
            return orders;
        }

        public void update_order(order ord)
        {
            newconnection.connection_today();
            string query = "UPDATE [Order] SET UserID=@UserID,total=@total  WHERE OrderId = @ID; ";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@UserID", ord.UserID);
            cmd.Parameters.AddWithValue("@ID", ord.OrderId);
            cmd.Parameters.AddWithValue("@total", ord.total);
            cmd.ExecuteNonQuery();

            
        }


    }
}
