﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using juicBarTry;
namespace new_object
{
    class category
    {
        public int catID { get; set; }
        public string catName { get; set; }
        //   static private SqlConnection connect = new SqlConnection("Data Source=.;Initial Catalog=Juice;Integrated Security=True");
        static singletone newconnection = new singletone();
        public static void  ADD_CATE(string NAME)
        {
            newconnection.connection_today();
            string query = "insert into cata values(@NAME)";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;

            cmd.Parameters.AddWithValue("@NAME", NAME);
            cmd.ExecuteNonQuery();

            
        }

        public static void delete_cat(int ID)
        {
            newconnection.connection_today();
            string query = "DELETE FROM cata WHERE catID=@ID;";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;

            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.ExecuteNonQuery();

            
        }
        public void select_cat(int ID)
        {
            newconnection.connection_today();
            string query = "select* FROM cata WHERE catID=@ID;";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;

            cmd.Parameters.AddWithValue("@ID", ID);
            
          SqlDataReader reader=cmd.ExecuteReader();
            reader.Read();
            this.catName = reader["catName"].ToString();
            this.catID = Convert.ToInt32(reader["catID"]);


            
        }
        public static List<category> selectAll()
        {newconnection.connection_today();
            string query = "select * from cata;";
            List<category> categores = new List<category>();
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;

            SqlDataReader reader = cmd.ExecuteReader();
            while(reader.Read())
            {
                category cat = new category();
                cat.catName = reader["catName"].ToString();
                cat.catID = Convert.ToInt32(reader["catID"]);
                categores.Add(cat);
           }
            
            return categores;
        }
        public static void update_CATE(category cat)
        {
            newconnection.connection_today();
            string query = "UPDATE cata SET catName=@NAME  WHERE catID = @ID; ";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;

            cmd.Parameters.AddWithValue("@NAME", cat.catName);
            cmd.Parameters.AddWithValue("@ID",cat.catID);
            cmd.ExecuteNonQuery();
            
            
        }

    }
}
