﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace juicBarTry
{
    public class User
    {
        public int id { get; set; }
        public string userName { get; set; }
        public string password { get; set; }
        public int isAdmin { get; set; }
        //private static SqlConnection Connect = new SqlConnection("Data Source=.;Initial Catalog=Juice;Integrated Security=True");
        static singletone newconnection = new singletone();
        public User()
        {
           
        }


        public void selectWithId(int id)
        {
            newconnection.connection_today();
            string query = "select * from users where id =@id";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@id", id);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            this.id = Convert.ToInt32(reader["id"].ToString());
            this.userName = reader["username"].ToString();
            this.isAdmin  = Convert.ToInt32(reader["isAdmin"].ToString());
           

        }
        // return all users 
        public static List<User> selectAll()
        {
            newconnection.connection_today();
            string query = "select * from users;";
            List<User> users = new List<User>();
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            SqlDataReader reader = cmd.ExecuteReader();
            
            while (reader.Read())
            {
                string useID = reader["id"].ToString();
                int userid = Convert.ToInt32(useID);
                User us = new User();
                us.id = userid;
                us.userName  = reader["username"].ToString();
                us.password  = reader["password"].ToString();
                us.isAdmin = Convert.ToInt32(reader["isAdmin"].ToString());
                users.Add(us);
            }
            

            return users;
        }
        

        // add new user.
        public static void addTo(string username,string password, int isAdmin=1)
        {
            newconnection.connection_today();
            string query = "insert into users values(@username,@password,@isAdmin)";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@isAdmin", isAdmin);
            cmd.ExecuteNonQuery();
            
        }


        public static void deleteWithID(int id)
        {
            newconnection.connection_today();
            string query = "delete from users where id=@id";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            
        }

        public static void update(User user)
        {
            newconnection.connection_today();
            string query = "UPDATE users set username=@user,password=@pass,isAdmin=@p where id=@id";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@id", user.id);
            cmd.Parameters.AddWithValue("@user", user.userName);
            cmd.Parameters.AddWithValue("@pass", user.password);
            cmd.Parameters.AddWithValue("@p", user.isAdmin);
            cmd.ExecuteNonQuery();
            
        }

        public static bool contains(string user,string password)
        {
            bool isExist = false;
            foreach (var i in User.selectAll())
            {
                if (i.userName == user && i.password == password)
                {
                    isExist = true;
                    return isExist;
                }
               
            }

            return isExist;
        }
    }
}
