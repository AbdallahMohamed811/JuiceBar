﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace juicBarTry
{
    class emp
    {
        public int Empid { get; set; }
        public string EmpName { get; set; }
        public string EmpSalary { get; set; }
        public string Sdate { get; set; }
        public int roleID { get; set; }
        public int UserId { get; set; }



        //        private static SqlConnection Connect = new SqlConnection("Data Source=.;Initial Catalog=Juice;Integrated Security=True");
        //select with id
        static singletone newconnection = new singletone();
        public emp()
        {

        }
        public void selectWithId(int id)
        {
            newconnection.connection_today();
            string query = "select * from Employee1 where Emp_ID =@id";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@id", id);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            this.Empid = Convert.ToInt32(reader["Emp_ID"].ToString());
            this.EmpName = reader["Emp_Name"].ToString();
            this.EmpSalary = reader["Emp_Salary"].ToString();
            this.Sdate = reader["Start_Date"].ToString();
            this.UserId = Convert.ToInt32(reader["User_ID"]);
            this.roleID = Convert.ToInt32(reader["roleID"]);
            

        }

        // select All

        public static List<emp> selectAll()
        {
            newconnection.connection_today();
            string query = "select * from Employee1;";
            List<emp> emps = new List<emp>();
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                string Empid = reader["Emp_ID"].ToString();
                int Empid2 = Convert.ToInt32(Empid);
                emp us = new emp();
                us.Empid = Empid2;
                us.EmpName = reader["Emp_Name"].ToString();
                us.EmpSalary = reader["Emp_Salary"].ToString();
                us.UserId = Convert.ToInt32(reader["User_ID"]);
                us.Sdate= reader["Start_Date"].ToString();
                emps.Add(us);

            }

            

            return emps;

        }
        // add new emp.
        public static void addTo(emp em)
        {
            newconnection.connection_today();
            string query = "insert into Employee1 values(@Emp_Name,@Emp_Salary,@Start_Date,@roleID,@userID)";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@userID", em.UserId);
            cmd.Parameters.AddWithValue("@Emp_Name", em.EmpName);
            cmd.Parameters.AddWithValue("@Emp_Salary", em.EmpSalary.ToString());
            cmd.Parameters.AddWithValue("@roleID", em.roleID);
            cmd.Parameters.AddWithValue("@Start_Date", DateTime.Now);
            cmd.ExecuteNonQuery();
            
        }

        // delete

        public static void deleteWithID(int id)
        {
            newconnection.connection_today();
            string query = "delete from Employee1 where Emp_ID=@id";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            
        }

        // update 

        public static void update(emp emps)
        {
            newconnection.connection_today();
            string query = "UPDATE Employee1 set Emp_Name=@pn,Emp_Salary=@s,Start_Date=@pass where Emp_ID=@id";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@id", emps.Empid);
            cmd.Parameters.AddWithValue("@pn", emps.EmpName);
            cmd.Parameters.AddWithValue("@s", emps.EmpSalary);
            cmd.Parameters.AddWithValue("@pass", emps.Sdate);
            cmd.ExecuteNonQuery();
            
        }

        
    }
}
