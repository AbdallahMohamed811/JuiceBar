﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using juicBarTry;
namespace jucie
{
    class MWhareHouse
    {
        public int id { get; set; }

        public string productName { get; set; }

        public int quantity { get; set; }

        public string price { get; set; }

        public string date { get; set; }

        public string totalPrice { get; set; }
        //        static private SqlConnection connect = new SqlConnection("Data Source=.;Initial Catalog=Juice;Integrated Security=True");
        static singletone newconnection = new singletone();
        public void selectWithId(int id)
        {
            newconnection.connection_today();
            string query = "select * from wharehouse where id =@id";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@id",id);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            this.id = Convert.ToInt32(reader["id"].ToString());
            this.productName = reader["productName"].ToString();
            this.quantity = Convert.ToInt32(reader["quantity"].ToString());
            this.date =reader["date"].ToString();
            this.totalPrice = reader["total price"].ToString();
         

        }

        // return MWhareHouse 
        public static List<MWhareHouse> selectAll()
        {
            newconnection.connection_today();
            string query = "select * from wharehouse;";
            List<MWhareHouse> ware = new List<MWhareHouse>();
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                string useID = reader["id"].ToString();
                int userid = Convert.ToInt32(useID);
                MWhareHouse us = new MWhareHouse();
                us.id = userid;
                us.productName = reader["productName"].ToString();
                us.quantity =Convert.ToInt32 (reader["quantity"].ToString());
                us.price = reader["price"].ToString();
                us.date = reader["date"].ToString();
                us.totalPrice = reader["total price"].ToString();
                ware.Add(us);
            }
           

            return ware;
        }

        // add new warehouse.
        public static void addTo(MWhareHouse ware)
        {
            newconnection.connection_today();
            string query = "insert into wharehouse values(@prouctName,@quantity,@price,@date,@totprice)";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@prouctName", ware.productName);
            cmd.Parameters.AddWithValue("@quantity", ware.quantity);
            cmd.Parameters.AddWithValue("@price", ware.price);
            cmd.Parameters.AddWithValue("@date", ware.date);
            cmd.Parameters.AddWithValue("@totprice", ware.totalPrice);
            cmd.ExecuteNonQuery();
                 }

        public static void deleteWithID(int id)
        {
            newconnection.connection_today();
            string query = "delete from wharehouse where id=@id";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
        }

        public static void update(MWhareHouse ware)
        {
            newconnection.connection_today();
            string query = "UPDATE wharehouse set productName=@productName,quantity=@quantity, price=@price,date=@date, [total price]=@totprice  where id=@id";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@id",ware.id);
            cmd.Parameters.AddWithValue("@productName", ware.productName);
            cmd.Parameters.AddWithValue("@quantity", ware.quantity);
            cmd.Parameters.AddWithValue("@price", ware.price);
            cmd.Parameters.AddWithValue("@date", ware.date);
            cmd.Parameters.AddWithValue("@totprice", ware.totalPrice);
            cmd.ExecuteNonQuery();
            
        }

    }
}

