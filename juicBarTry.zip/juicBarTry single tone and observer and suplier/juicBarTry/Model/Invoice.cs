﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using juicBarTry;

namespace new_object
{
    class Invoice
    {
        public int InvoiceID { get; set; }
        public int OrderID { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string ProductPrice { get; set; }
        public int Quantity { get; set; }
        public int TotPrc { get; set; }

        private static SqlConnection connect = new SqlConnection("Data Source=.;Initial Catalog=Juice;Integrated Security=True");

        public void ADD_inv(Invoice inv)
        {

            string query = "insert into Invoice values(@OrderID,@ProductId,@Quantity,@TotPrc)";
            connect.Open();

            SqlCommand cmd = new SqlCommand(query, connect);
            cmd.Parameters.AddWithValue("@OrderID", inv.OrderID);
            cmd.Parameters.AddWithValue("@ProductId", inv.ProductId);
            cmd.Parameters.AddWithValue("@Quantity", inv.Quantity);
            cmd.Parameters.AddWithValue("@TotPrc", inv.TotPrc);
            cmd.ExecuteNonQuery();

            connect.Close();
        }

        public void delete_inv(int ID)
        {
            string query = "DELETE FROM Invoice WHERE InvoiceID=@ID;";
            connect.Open();
            SqlCommand cmd = new SqlCommand(query, connect);

            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.ExecuteNonQuery();

            connect.Close();
        }
        public void select_inv(int ID)
        {
            string query = "select* FROM Invoice WHERE InvoiceID=@ID;";
            connect.Open();
            SqlCommand cmd = new SqlCommand(query, connect);

            cmd.Parameters.AddWithValue("@ID", ID);

            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            this.InvoiceID = Convert.ToInt32(reader["InvoiceID"]);
            this.OrderID =int.Parse( reader["OrderID"].ToString());
            this.ProductId = int.Parse(reader["ProductId"].ToString());
            this.Quantity = int.Parse(reader["Quantity"].ToString());
            this.TotPrc = Convert.ToInt32(reader["TotPrc"]);



            connect.Close();
        }
        public static List<Invoice> selectAll()
        {
            var orderid = order.selectAll()[order.selectAll().Count - 1].OrderId;
            string query = "SELECT[Product].productID,[Order].[Date],[Product].productName,[Invoice].Quantity,[Product].price,[Invoice].TotPrc,[Invoice].InvoiceID,[Order].[OrderID] from[Invoice] INNER JOIN[Order] ON[Invoice].OrderID=[Order].OrderID INNER JOIN Product ON[Invoice].ProductID=Product.productID WHERE[Order].[OrderID]=@id";
          //  string query = "SELECT[Product].ProductID,[Order].[Date],[Product].productName,[Invoice].Quantity,[Product].price,[Invoice].TotPrc,[Invoice].InvoiceID,[Order].[OrderID] from[Invoice] INNER JOIN[Order] ON[Invoice].OrderID=[Order].OrderID INNER JOIN Product ON[Invoice].ProductID=Product.productID WHERE[Order].[OrderID]=@id";
            List<Invoice> invoices = new List<Invoice>();
            connect.Open();
            SqlCommand cmd = new SqlCommand(query, connect);
            cmd.Parameters.AddWithValue("@id", orderid);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Invoice inv = new Invoice();
                inv.InvoiceID = int.Parse(reader["InvoiceID"].ToString());
                inv.ProductId = int.Parse(reader["ProductId"].ToString());
                inv.ProductName = reader["productName"].ToString();
                inv.ProductPrice = reader["price"].ToString();
                inv.Quantity = int.Parse(reader["Quantity"].ToString());
                inv.TotPrc = Convert.ToInt32(reader["TotPrc"]);
                inv.OrderID = Convert.ToInt32(reader["OrderID"]);
                invoices.Add(inv);
            }
            connect.Close();
            return invoices;
        }
        public static void update_inv(Invoice inv)
        {
            string query = "UPDATE Invoice SET OrderID=@OrderID,ProductId=@ProductId,Quantity=@Quantity,TotPrc=@TotPrc  WHERE InvoiceID=@ID ";
            connect.Open();
            SqlCommand cmd = new SqlCommand(query, connect);

            cmd.Parameters.AddWithValue("@ID", inv.InvoiceID);
            cmd.Parameters.AddWithValue("@OrderID", inv.OrderID);
            cmd.Parameters.AddWithValue("@ProductId", inv.ProductId);
            cmd.Parameters.AddWithValue("@Quantity", inv.Quantity);
            cmd.Parameters.AddWithValue("@TotPrc", inv.TotPrc);
            cmd.ExecuteNonQuery();

            connect.Close();
        }





    }
}
