﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace juicBarTry.Model
{
    class suplier
    {
        public int sup_id { get; set; }
        public string sup_name { get; set; }
        public int sup_number { get; set; }
        public string location { get; set; }
        public string email { get; set; }
       // public int product_id { get; set; }
        static singletone newconnection = new singletone();

        public void selectWithId(int id)
        {
            newconnection.connection_today();
            string query = "select * from suplier where sup_id =sup_id";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@id", id);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            this.sup_id = Convert.ToInt32(reader["sup_id"].ToString());
            this.sup_name = reader["sup_name"].ToString();
            this.email = reader["email"].ToString();
            this.location = reader["location"].ToString();
            this.sup_number = Convert.ToInt32(reader["sup_number"]);
          //  this.product_id = Convert.ToInt32(reader["product_id"]);


        }
        public static List<suplier> selectAll()
        {
            newconnection.connection_today();
            string query = "select * from suplier;";
            List<suplier> emps = new List<suplier>();

            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                string sup_id = reader["sup_id"].ToString();
                int Empid2 = Convert.ToInt32(sup_id);
                suplier us = new suplier();
                us.sup_id = Empid2;
                us.sup_name = reader["sup_name"].ToString();
                us.email = reader["email"].ToString();
                us.sup_number = Convert.ToInt32(reader["sup_number"]);
                us.location = reader["location"].ToString();
               // us.product_id = Convert.ToInt32(reader["product_id"]);
                emps.Add(us);

            }



            return emps;

        }
        public static void addTo(suplier su)
        {
            newconnection.connection_today();
            string query = "insert into suplier values(@sup_name,@sup_number,@location,@email)";

            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@sup_name", su.sup_name);
            cmd.Parameters.AddWithValue("@sup_number", su.sup_number);
            cmd.Parameters.AddWithValue("@location", su.location.ToString());
            cmd.Parameters.AddWithValue("@email", su.email);
           // cmd.Parameters.AddWithValue("@product_id", su.product_id);
            cmd.ExecuteNonQuery();

        }
        public static void update(suplier emps)
        {
            newconnection.connection_today();
            string query = "UPDATE suplier set sup_name=@pn,sup_number=@s,location=@pass,email=@email where sup_id=@id";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@id", emps.sup_id);
            cmd.Parameters.AddWithValue("@pn", emps.sup_name);
            cmd.Parameters.AddWithValue("@s", emps.sup_number);
            cmd.Parameters.AddWithValue("@pass", emps.location);
            cmd.Parameters.AddWithValue("@email", emps.email);
            //cmd.Parameters.AddWithValue("@product_id", emps.product_id);
            cmd.ExecuteNonQuery();

        }

        public static void deleteWithID(int id)
        {
            newconnection.connection_today();
            string query = "delete from suplier where sup_id=@id";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();

        }



    }
}
