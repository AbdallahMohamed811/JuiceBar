﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using juicBarTry;
namespace new_object
{
    class role
    {
        public int roleId { get; set; }
        public string rolename { get; set; }
        //  private static SqlConnection connect = new SqlConnection("Data Source=.;Initial Catalog=Juice;Integrated Security=True");
        static singletone newconnection = new singletone();


        public static void ADD_role(string NAME)
        {
            newconnection.connection_today();
            string query = "insert into role values(@NAME)";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@NAME", NAME);
            cmd.ExecuteNonQuery();

            
        }
        public static void delete_role(int ID)
        {
            newconnection.connection_today();
            string query = "DELETE FROM role WHERE roleId=@ID;";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.ExecuteNonQuery();

            
        }
        public void select_role(int ID)
        {
            newconnection.connection_today();
            string query = "select* FROM role WHERE roleId=@ID;";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@ID", ID);

            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            this.roleId = Convert.ToInt32(reader["roleid"]);
            this.rolename = reader["rolename"].ToString();


            
        }
        public static List<role> selectAll()
        {
            newconnection.connection_today();
            string query = "select * from role;";
            List<role> roles = new List<role>();
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                role rr = new role();
                rr.rolename = reader["rolename"].ToString();
                rr.roleId = Convert.ToInt32(reader["roleid"]);
                roles.Add(rr);
            }
            
            return roles;
        }
        public static void update_role(role rr)
        {
            newconnection.connection_today();
            string query = "UPDATE role SET rolename=@NAME  WHERE roleId = @ID; ";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@NAME", rr.rolename);
            cmd.Parameters.AddWithValue("@ID", rr.roleId);
            cmd.ExecuteNonQuery();

            
        }


    }
}
