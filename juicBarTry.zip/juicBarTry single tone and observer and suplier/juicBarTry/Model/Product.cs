﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using juicBarTry;
namespace new_object
{
    class Product
    {
        public int productID { get; set; }
        public string productName { get; set; }
        public String price { get; set; }
        public int catID { get; set; }
        public int quantity { get; set; }
        public int wholesalePrice { get; set; }

        //     static private SqlConnection connect = new SqlConnection("Data Source=.;Initial Catalog=Juice;Integrated Security=True");
        static singletone newconnection = new singletone();
        public void ADD_pro(string productName,int price,int catID,int quantity,int wholesale)
        {
            newconnection.connection_today();
            string query = "insert into Product values(@productName,@price,@catID,@quantity,@wholesalePrrice)";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@productName", productName);
            //cmd.Parameters.AddWithValue("@storeID", storeID);
            cmd.Parameters.AddWithValue("@price", price);
            cmd.Parameters.AddWithValue("@catID", catID);
            cmd.Parameters.AddWithValue("@quantity", quantity);
            cmd.Parameters.AddWithValue("@wholesalePrrice", wholesale);
            cmd.ExecuteNonQuery();

            
        }
        public static void delete_pro(int ID)
        {
            newconnection.connection_today();
            string query = "DELETE FROM Product WHERE productID=@ID;";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.ExecuteNonQuery();

           
        }
        public void select_product(int ID)
        {
            newconnection.connection_today();
            string query = "select* FROM Product WHERE productID=@ID;";
           
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@ID", ID);

            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();

            this.productID = Convert.ToInt32(reader["productID"]);
            this.productName = reader["productName"].ToString();
            this.catID = int.Parse(reader["catID"].ToString());
            this.price = reader["price"].ToString();
            this.quantity = Convert.ToInt32(reader["quantity"]);
            this.wholesalePrice = Convert.ToInt32(reader["wholesalePrrice"]);

            
        }
        public static List<Product> selectAll()
        {
            newconnection.connection_today();
            string query = "select * from Product;";
            List<Product> products = new List<Product>();
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Product pro = new Product();
                pro.productID = Convert.ToInt32(reader["productID"]);
                pro.productName = reader["productName"].ToString();
                pro.catID = Convert.ToInt32(reader["catID"]);
                pro.price = reader["price"].ToString();
                //pro.storeID = Convert.ToInt32(reader["storeID"]);
                pro.quantity = Convert.ToInt32(reader["quantity"]);
                pro.wholesalePrice = Convert.ToInt32(reader["wholesalePrrice"]);
                products.Add(pro);
            }
            
            return products;
        }

        public static void update_pro(Product pro)
        {
            newconnection.connection_today();
            string query = "UPDATE Product SET productName=@productName,catID=@catID,price=@price,quantity=@qyt WHERE productID = @ID;";
            
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = singletone.conn;
            cmd.Parameters.AddWithValue("@productName", pro.productName);
            cmd.Parameters.AddWithValue("@ID", pro.productID);
            cmd.Parameters.AddWithValue("@catID", pro.catID);
            cmd.Parameters.AddWithValue("@price", pro.price);
            cmd.Parameters.AddWithValue("@qyt", pro.quantity);

            cmd.ExecuteNonQuery();

            
        }

    }
}
