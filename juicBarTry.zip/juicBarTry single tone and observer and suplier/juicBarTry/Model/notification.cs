﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tulpep.NotificationWindow;

namespace juicBarTry.Model
{
   
    class notification
    {
        private static List<PopupNotifier> p = new List<PopupNotifier>();
        int i = 0;

        public static PopupNotifier pushNotification(string title,string text)
        {
            
            PopupNotifier pop = new PopupNotifier();
            //pop.Image = Properties.Resources.;
            pop.BodyColor = System.Drawing.Color.OldLace;
            pop.BorderColor = System.Drawing.Color.Goldenrod;
            pop.HeaderColor = System.Drawing.Color.Goldenrod;
            pop.ImagePadding = new Padding(10, 20, 10, 10);
            pop.TitlePadding = new Padding(10, 25, 0, 0);
            pop.ContentPadding = new Padding(10, 0, 0, 0);
            pop.TitleColor = Color.Red;
            pop.TitleText = title;
            pop.ContentText = text;

            return pop;

        }

       
    }
}
