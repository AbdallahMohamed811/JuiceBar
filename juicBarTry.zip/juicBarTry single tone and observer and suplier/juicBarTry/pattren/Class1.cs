﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsApp2.Subject;

namespace WindowsFormsApp2
{
    class Class1 : iSubject
    {
        private IList<iObserver> obs;
        private int count;
        private string name;
       public void pushnoti()
        {
            if (count < 5)
            {
                NotifyObserver(count,name);
            }
        }
        public Class1()
        {
            obs = new List<iObserver>();
            count = 0;
        }
        public void NotifyObserver(int count,string name)
        {
            foreach(iObserver observer in obs)
            {
                observer.update(count,name);
            }

        }
        

        public void registerObserver(iObserver ob)
        {
            obs.Add(ob);
        }

        public void unregisterObserver(iObserver ob)
        {
            obs.Remove(ob);
        }
    }
}
