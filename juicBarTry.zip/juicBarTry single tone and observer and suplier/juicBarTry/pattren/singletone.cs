﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace juicBarTry
{
    class singletone
    {
        public static SqlConnection conn = null;
        public void connection_today()
        {
            conn = new SqlConnection("Data Source=MOHANADGAD9C28\\SQLEXPRESS;Initial Catalog=juice;Integrated Security=True");
            conn.Open();
        }
    }
}

