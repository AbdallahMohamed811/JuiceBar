﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2.Subject
{
    public interface iSubject
    {
        void registerObserver(iObserver ob);
        void unregisterObserver(iObserver ob);
        void NotifyObserver(int count,string name);
    }
}
