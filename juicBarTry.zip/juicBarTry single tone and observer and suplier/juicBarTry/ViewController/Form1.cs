﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using juicBarTry.ViewController;

namespace juicBarTry
{

    public partial class Form1 : Form
    {


        public static int userID;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
     
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dashboard dash = new dashboard();
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter your First Name");
                textBox1.Focus();
                }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("Please enter your First password");
                textBox2.Focus();
            }
            else
            {
                foreach (var i in User.selectAll())
                {
                    if (i.userName == textBox1.Text && i.password == textBox2.Text)
                    {
                        if (i.isAdmin == 1)
                        {
                            dash.Show();
                        }
                        else
                        {
                            AddNewOrder order = new AddNewOrder();
                            order.Show();
                        }
                        userID = i.id;
                    }

                }

                if (User.contains(textBox1.Text, textBox2.Text))
                {

                }
                else
                    MessageBox.Show("invalid Username or Password");
            }
        }
    }
}
