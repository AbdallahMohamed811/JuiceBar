﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using jucie;
using juicBarTry;
using new_object;
using System.IO;
using System.Diagnostics;
using DGVPrinterHelper;

namespace OOSE_GUI
{
    public partial class View_Employees_List : Form
    {
        int curentRow = -1;
        public View_Employees_List()
        {
            InitializeComponent();
        }

        private void View_Employees_List_Load(object sender, EventArgs e)
        {


            fill();
            dataGridView1.CellClick += DataGridView1_CellClick;
            comboBox1.DataSource = role.selectAll();
            comboBox1.DisplayMember = "rolename";
            comboBox1.ValueMember = "roleid";

        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            curentRow = dataGridView1.CurrentCell.RowIndex;
            textBox1.Text = dataGridView1.Rows[curentRow].Cells["EmpName"].Value.ToString();
            textBox3.Text = dataGridView1.Rows[curentRow].Cells["EmpSalary"].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Add_Employee add_Employee = new Add_Employee();
            add_Employee.Show();
            this.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter your   name");
                textBox1.Focus();
            }
          
            else if (textBox3.Text == "")
            {
                MessageBox.Show("Please enter your  salary");
                textBox3.Focus();
            }
            else
            {
                string hhhh = textBox1.Text.Trim();
                textBox1.Text = hhhh;
                
                hhhh=textBox3.Text.Trim();
                textBox3.Text = hhhh;
                int id = Convert.ToInt32(dataGridView1.Rows[curentRow].Cells["Empid"].Value);
                emp employ = new emp();
                employ.selectWithId(id);
                employ.EmpName = textBox1.Text;

                employ.EmpSalary = textBox3.Text;
                 emp.update(employ);
                fill();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            emp.deleteWithID(Convert.ToInt32(dataGridView1.Rows[curentRow].Cells["Empid"].Value));
            fill();
        }

        void fill()
        {
            BindingSource bindingSource1 = new BindingSource();
            foreach (var i in emp.selectAll())
            {
                bindingSource1.Add(i);
            }
            dataGridView1.DataSource = bindingSource1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DGVPrinter printer = new DGVPrinter(); printer.Title = "Category Report";
            printer.SubTitle = "Category"; printer.SubTitleFormatFlags = StringFormatFlags.LineLimit |
            StringFormatFlags.NoClip; printer.PageNumbers = true;
            printer.PageNumberInHeader = false;
            printer.ColumnWidth = DGVPrinter.ColumnWidthSetting.Porportional; printer.HeaderCellAlignment = StringAlignment.Near; printer.Footer = "Your Company Name Here";
            printer.FooterSpacing = 15;

            printer.PrintDataGridView(dataGridView1);
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
        (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }
    }
}
