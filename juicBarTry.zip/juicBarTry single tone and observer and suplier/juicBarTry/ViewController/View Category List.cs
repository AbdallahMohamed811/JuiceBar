﻿using juicBarTry;
using new_object;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using DGVPrinterHelper;

namespace OOSE_GUI
{

   
    public partial class View_Category_List : Form
    {
       
       
        int curentRow = -1;
        public View_Category_List()
        {
            InitializeComponent();
            dataGridView1.CellClick += DataGridView1_CellClick;
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            curentRow = dataGridView1.CurrentCell.RowIndex;
            textBox1.Text = dataGridView1.Rows[curentRow].Cells["catName"].Value.ToString();
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
                Add_Category add_Category = new Add_Category();
                add_Category.Show();
                //this.Close();
            
        }

        private void View_Category_List_Load(object sender, EventArgs e)
        {
            fillDataGrid();
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }
        private void fillDataGrid()
        {
            BindingSource bindingSource1 = new BindingSource();
            foreach (var i in category.selectAll())
            {
                bindingSource1.Add(i);
            }
            dataGridView1.DataSource = bindingSource1;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.RowHeadersVisible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter your   name");
                textBox1.Focus();
            }
            else
            {
                string hhhh = textBox1.Text.Trim();
                textBox1.Text = hhhh;


                int id = Convert.ToInt32(dataGridView1.Rows[curentRow].Cells["catID"].Value);

                category cata = new category();
                cata.select_cat(id);
                cata.catName = textBox1.Text;
                category.update_CATE(cata);
                fillDataGrid();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(dataGridView1.Rows[curentRow].Cells["catID"].Value);
            category.delete_cat(id);
            fillDataGrid();

        }

        // print and to pdf.
        private void button4_Click(object sender, EventArgs e)
        {
            DGVPrinter printer = new DGVPrinter(); printer.Title = "Category Report";
            printer.SubTitle = "Category"; printer.SubTitleFormatFlags = StringFormatFlags.LineLimit |
            StringFormatFlags.NoClip; printer.PageNumbers = true;
            printer.PageNumberInHeader = false;
            printer.ColumnWidth = DGVPrinter.ColumnWidthSetting.Porportional; printer.HeaderCellAlignment = StringAlignment.Near; printer.Footer = "Your Company Name Here";
            printer.FooterSpacing = 15;

            printer.PrintDataGridView(dataGridView1);
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }
    }
}
