﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace juicBarTry.ViewController
{
    public partial class usersForm : Form
    {
        
        int curentRow = -1;
        public usersForm()
        {
            InitializeComponent();
        }
        private void usersForm_Load(object sender, EventArgs e)
        {

            fill();

            dataGridView1.CellClick += DataGridView1_CellClick;
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            curentRow = dataGridView1.CurrentCell.RowIndex;
            textBox1.Text = dataGridView1.Rows[curentRow].Cells["username"].Value.ToString();
            textBox2.Text = dataGridView1.Rows[curentRow].Cells["password"].Value.ToString();
            textBox3.Text = dataGridView1.Rows[curentRow].Cells["isAdmin"].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            User.deleteWithID(Convert.ToInt32(dataGridView1.Rows[curentRow].Cells["id"].Value));
            fill();
        }

        void fill()
        {
             BindingSource bindingSource1 = new BindingSource();
            foreach (var i in User.selectAll())
            {
                bindingSource1.Add(i);
            }
            dataGridView1.DataSource = bindingSource1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter your   name");
                textBox1.Focus();
            }

            else if (textBox2.Text == "")
            {
                MessageBox.Show("Please enter your  passwrod");
                textBox2.Focus();
            }
            else if (textBox3.Text == "")
            {
                MessageBox.Show("Please enter your  isadmin");
                textBox3.Focus();
            }
            else
            {
                string hhhh = textBox1.Text.Trim();
                textBox1.Text = hhhh;

                hhhh = textBox3.Text.Trim();
                textBox3.Text = hhhh;

                hhhh = textBox2.Text.Trim();
                textBox2.Text = hhhh;

                User user = new User();
                user.selectWithId(Convert.ToInt32(dataGridView1.Rows[curentRow].Cells["id"].Value));
                user.password = textBox2.Text;
                user.userName = textBox1.Text;
                user.isAdmin = Convert.ToInt32(textBox3.Text.ToString());
                User.update(user);
                fill();
            }

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
        (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AddUserform g = new AddUserform();
            g.Show();
           
        }
    }
}
