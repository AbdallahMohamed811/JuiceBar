﻿using OOSE_GUI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp2;

namespace juicBarTry.ViewController
{
    public partial class dashboard : Form
    {

        Class1 c;
       
        public dashboard()
        {
            c = new Class1();
            InitializeComponent();
        }

        private void dashboard_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            usersForm user = new usersForm();
            user.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            View_Category_List cat = new View_Category_List();
            cat.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            View_Products view_Products = new View_Products();
            view_Products.Show();
            c.registerObserver(view_Products);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            View_WareHouse ware = new View_WareHouse();
            ware.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            view_suplier product = new view_suplier();
            product.Show();
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            View_Employees_List em = new View_Employees_List();
            em.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            View_Rloes ro = new View_Rloes();
            ro.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            AddNewOrder order = new AddNewOrder();
            order.Show();
            c.registerObserver(order);
        }
    }
}
