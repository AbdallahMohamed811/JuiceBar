﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using juicBarTry;
using jucie;

namespace OOSE_GUI
{
    public partial class WareHouse : Form
    {
        public WareHouse()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MWhareHouse ware = new MWhareHouse();
            ware.productName = textBox1.Text;
            ware.price = textBox3.Text;
            ware.quantity = Convert.ToInt32(textBox2.Text);
            ware.date = dateTimePicker1.Value.ToString();
            ware.totalPrice = (Convert.ToInt32(ware.price)  * ware.quantity).ToString();
            MWhareHouse.addTo(ware);
            MessageBox.Show("succes");
        }

        private void WareHouse_Load(object sender, EventArgs e)
        {

        }

       
    }
}
