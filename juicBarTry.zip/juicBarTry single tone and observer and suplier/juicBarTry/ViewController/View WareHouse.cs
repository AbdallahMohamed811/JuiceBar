﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using jucie;
using System.IO;
using System.Diagnostics;
using DGVPrinterHelper;


namespace OOSE_GUI
{
    public partial class View_WareHouse : Form
    {
        int curentRow = -1;
        double tot = 0;
        public View_WareHouse()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter your  product name");
                textBox2.Focus();
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("Please enter your  price");
                textBox2.Focus();
            }
            else if (textBox3.Text == "")
            {
                MessageBox.Show("Please enter your  quantity");
                textBox3.Focus();
            }
            else
            {
                string hhhh=textBox1.Text.Trim();
                textBox1.Text = hhhh;
                textBox2.Text.Trim();
                textBox3.Text.Trim();
                int id = Convert.ToInt32(dataGridView1.Rows[curentRow].Cells["id"].Value);

                MWhareHouse ware = new MWhareHouse();
                ware.selectWithId(id);
                ware.productName = textBox1.Text;

                ware.price = textBox2.Text.ToString();
                int quantity;
                int.TryParse(textBox3.Text, out quantity);
                ware.quantity = quantity;
                float price;
                float.TryParse(textBox2.Text, out price);
                ware.price = price.ToString() ;
                ware.totalPrice = (price * ware.quantity).ToString();
                MWhareHouse.update(ware);
                fill();
            }
        }   
        private void button3_Click(object sender, EventArgs e)
        {
            WareHouse wareHouse = new WareHouse();
            wareHouse.Show();
            this.Close();
        }

        private void View_WareHouse_Load(object sender, EventArgs e)
        {

            dataGridView1.CellClick += DataGridView1_CellClick1;
            fill();
        }

        private void DataGridView1_CellClick1(object sender, DataGridViewCellEventArgs e)
        {
            curentRow = dataGridView1.CurrentCell.RowIndex;
            textBox1.Text = dataGridView1.Rows[curentRow].Cells["productName"].Value.ToString();
            textBox2.Text = dataGridView1.Rows[curentRow].Cells["price"].Value.ToString();
            textBox3.Text = dataGridView1.Rows[curentRow].Cells["quantity"].Value.ToString();
        }

        void fill()
        {
           
            BindingSource bindingSource1 = new BindingSource();
            tot = 0;
            foreach (var i in MWhareHouse.selectAll())
            {
                bindingSource1.Add(i);

                tot += Convert.ToDouble(i.totalPrice);



            }
            label7.Text = tot.ToString();
            dataGridView1.DataSource = bindingSource1;
        }

        private void button2_Click(object sender, EventArgs e)
        {

            MWhareHouse.deleteWithID(Convert.ToInt32(dataGridView1.Rows[curentRow].Cells["id"].Value));
            fill();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DGVPrinter printer = new DGVPrinter(); printer.Title = "warehouse Report";
            printer.SubTitle = "warehouse"; printer.SubTitleFormatFlags = StringFormatFlags.LineLimit |
            StringFormatFlags.NoClip; printer.PageNumbers = true;
            printer.PageNumberInHeader = false;
            printer.ColumnWidth = DGVPrinter.ColumnWidthSetting.Porportional; printer.HeaderCellAlignment = StringAlignment.Near; printer.Footer = "juice bar";
            printer.FooterSpacing = 15;

            printer.PrintDataGridView(dataGridView1);
        }
    }
}
