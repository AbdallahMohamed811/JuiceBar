﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using new_object;
using System.IO;
using System.Diagnostics;
using DGVPrinterHelper;

namespace OOSE_GUI
{
    public partial class View_Rloes : Form
    {
        int curentRow = -1;
        public View_Rloes()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Add_New_Role add_New_Role = new Add_New_Role();
            add_New_Role.Show();
           
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter your   name");
                textBox1.Focus();
            }
            else
            {
                int id = Convert.ToInt32(dataGridView1.Rows[curentRow].Cells["roleid"].Value);
                role ro = new role();
                ro.select_role(id);
                ro.rolename = textBox1.Text;
                role.update_role(ro);
                textBox1.Text = "";
                fill();
            }
        }

        private void View_Rloes_Load(object sender, EventArgs e)
        {
            fill();
            dataGridView1.CellClick += DataGridView1_CellClick;
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            curentRow = dataGridView1.CurrentCell.RowIndex;
            textBox1.Text = dataGridView1.Rows[curentRow].Cells["rolename"].Value.ToString();
        }

        void fill()
        {
            BindingSource bindingSource1 = new BindingSource();

            foreach (var i in role.selectAll())
            {
                bindingSource1.Add(i);
            }
            dataGridView1.DataSource = bindingSource1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            role.delete_role(Convert.ToInt32(dataGridView1.Rows[curentRow].Cells["roleid"].Value));
            fill();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }
    }
}
