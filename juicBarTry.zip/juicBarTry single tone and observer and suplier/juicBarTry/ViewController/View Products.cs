﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using juicBarTry;
using new_object;
using System.IO;
using System.Diagnostics;
using DGVPrinterHelper;
using juicBarTry.Model;
using WindowsFormsApp2;

namespace OOSE_GUI
{
    public partial class View_Products : Form,iObserver
    {
        
        int curentRow = -1;
        public View_Products()
        {
            InitializeComponent();
           
        }


        //update product 
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter your   quantity");
                textBox1.Focus();
            }

            else if (textBox3.Text == "")
            {
                MessageBox.Show("Please enter your  name");
                textBox3.Focus();
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("Please enter your  price");
                textBox2.Focus();
            }
            else
            {
                Product pro = new Product();
                pro.select_product(Convert.ToInt32(dataGridView1.Rows[curentRow].Cells["productID"].Value));
                pro.productName = textBox3.Text.ToString();
                pro.price = textBox2.Text;
                pro.quantity = Convert.ToInt32(textBox1.Text);
                Product.update_pro(pro);
                update(pro.quantity,pro.productName);
                fill();
            }
        }

        private void View_Products_Load(object sender, EventArgs e)
        {
            fill();
            dataGridView1.CellClick += DataGridView1_CellClick;
            foreach (var i in Product.selectAll())
            {
                update(i.quantity,i.productName);
            }
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            curentRow = dataGridView1.CurrentCell.RowIndex;
            textBox3.Text = dataGridView1.Rows[curentRow].Cells["productName"].Value.ToString();
            textBox2.Text = dataGridView1.Rows[curentRow].Cells["price"].Value.ToString();
            textBox1.Text = dataGridView1.Rows[curentRow].Cells["quantity"].Value.ToString();


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        void fill()
        {
            // fill combobox
            comboBox1.DataSource = category.selectAll();
            comboBox1.DisplayMember = "catName";
            comboBox1.ValueMember = "catID";

            // fill datagrid
            BindingSource bindingSource1 = new BindingSource();
            foreach (var i in Product.selectAll())
            {
                bindingSource1.Add(i);
            }
            dataGridView1.DataSource = bindingSource1;


        }

        private void button3_Click(object sender, EventArgs e)
        {
            Add_New_Product product = new Add_New_Product();
            product.Show();

        }

        // delete record 
        private void button2_Click(object sender, EventArgs e)
        {
            Product.delete_pro(Convert.ToInt32(dataGridView1.Rows[curentRow].Cells["productID"].Value));
            fill();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DGVPrinter printer = new DGVPrinter(); printer.Title = "Category Report";
            printer.SubTitle = "Category"; printer.SubTitleFormatFlags = StringFormatFlags.LineLimit |
            StringFormatFlags.NoClip; printer.PageNumbers = true;
            printer.PageNumberInHeader = false;
            printer.ColumnWidth = DGVPrinter.ColumnWidthSetting.Porportional; printer.HeaderCellAlignment = StringAlignment.Near; printer.Footer = "Your Company Name Here";
            printer.FooterSpacing = 15;

            printer.PrintDataGridView(dataGridView1);
        }

     
        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
        (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        public void update(int count, string name)
        {
            if (count < 5)
                notification.pushNotification("run out of your "+ name, "run").Popup();
        }
    }
}
