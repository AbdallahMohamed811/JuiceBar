﻿using juicBarTry.Model;
using new_object;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DGVPrinterHelper;
using WindowsFormsApp2;

namespace juicBarTry.ViewController
{
    public partial class AddNewOrder : Form, iObserver
    {
        int productid;
        int ct =0;
        public AddNewOrder()
        {
            InitializeComponent();
        }

        private void AddNewOrder_Load(object sender, EventArgs e)
        {
            loadCategory();
           
          
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            String l = btn.Text;
            string id = "";
            for (int i = 0; i < l.Count(); i++)
            {
                if (int.TryParse(l[i].ToString(), out int n))
                {
                    id += l[i].ToString();
                }
                else
                {
                    break;
                }
            }
            productid = Convert.ToInt32(id);
            if (ct <= 0)
            {
                order ord = new order();
                ord.ADD_ord();
            }
            if (isExist()!= -1)
            {
                
                int invID = isExist();
                updateOrder(invID);
            }
            else
            {
                insertNewRecord();
            }
            fillDataGrid();
            ct++;

        }

        void loadCategory()
        {
            foreach (var row in Product.selectAll())
            {
                Button button = new Button();
                button.AutoSize = true;
                button.Width = 150;
                string s2 = string.Format("{0:#,0.#}", float.Parse(row.price));
                button.Text = row.productID + Environment.NewLine + row.productName + Environment.NewLine + s2 + " EGB";
                flowLayoutPanel1.AutoScroll = true;
                flowLayoutPanel1.Controls.Add(button);
                button.Click += Button_Click;
            }

        }
        void loadData()
        {

        }
        void insertNewRecord()
        {
           

            var orderid = order.selectAll()[order.selectAll().Count - 1].OrderId;
            Invoice inv = new Invoice();
            inv.ProductId = productid;
            inv.OrderID = orderid;
            inv.Quantity = 1;
            Product pro = new Product();
            pro.select_product(productid);
            pro.quantity--;
           
            Product.update_pro(pro);
            inv.ProductPrice = pro.price.ToString();
            float price = float.Parse(inv.ProductPrice) * inv.Quantity;
            inv.TotPrc = Convert.ToInt32(price);
            inv.ADD_inv(inv);
            update(pro.quantity,pro.productName);

        }
        void updateOrder(int id)
        {
            Invoice inv = new Invoice();
            inv.select_inv(id);
            inv.Quantity++;
            Product pro = new Product();
            pro.select_product(productid);
            pro.quantity--;
            Product.update_pro(pro);
            inv.ProductPrice = pro.price.ToString();
            float price = float.Parse(inv.ProductPrice) * inv.Quantity;
            inv.TotPrc = Convert.ToInt32(price);
            Invoice.update_inv(inv);
        }
        void fillDataGrid()
        {
            BindingSource bindingSource1 = new BindingSource();

            foreach (var i in Invoice.selectAll())
            {
                bindingSource1.Add(i);
            }
            dataGridView1.DataSource = bindingSource1;
        }

        int isExist()
        {
            var orderid = order.selectAll()[order.selectAll().Count - 1].OrderId;
            
            foreach(var i in Invoice.selectAll())
            {
                if (orderid == i.OrderID 
                    && productid == i.ProductId)
                {
                    
                    return i.InvoiceID;
                }
            }
           // MessageBox.Show("here");
            return -1;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int total = 0;
            var orderid = order.selectAll()[order.selectAll().Count - 1].OrderId;
            foreach (var i in Invoice.selectAll())
            {
                if (orderid == i.OrderID
                    && productid == i.ProductId)
                {
                    total += i.TotPrc;
                   
                }
            }
            //
            DGVPrinter printer = new DGVPrinter(); printer.Title = "price Report";
            printer.SubTitle = "price"; printer.SubTitleFormatFlags = StringFormatFlags.LineLimit |
            StringFormatFlags.NoClip; printer.PageNumbers = true;
            printer.PageNumberInHeader = false;
            printer.ColumnWidth = DGVPrinter.ColumnWidthSetting.Porportional; printer.HeaderCellAlignment = StringAlignment.Near; printer.Footer = "Your Company Name Here";
            printer.FooterSpacing = 15;

            printer.PrintDataGridView(dataGridView1);


            //
            order ord = new order();
            ord.select_ord(orderid);
            ord.total = total;
            ord.update_order(ord);
            ord.ADD_ord();
            fillDataGrid();
        }

        public void update(int count, string name)
        {
            if (count < 5)
                notification.pushNotification("run out of your "+ name, "run").Popup();
        }
    }
}
