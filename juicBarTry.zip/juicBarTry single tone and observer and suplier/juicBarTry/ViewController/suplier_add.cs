﻿using juicBarTry.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace juicBarTry.ViewController
{
    public partial class suplier_add : Form
    {
        public suplier_add()
        {
            InitializeComponent();
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
       (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter your  first name");
                textBox1.Focus();
            }

            else if (textBox3.Text == "")
            {
                MessageBox.Show("Please enter your last name");
                textBox3.Focus();
            }


            else if (textBox2.Text == "")
            {
                MessageBox.Show("Please enter your  number");
                textBox3.Focus();
            }
            else if (textBox4.Text == "")
            {
                MessageBox.Show("Please enter your  email");
                textBox4.Focus();
            }
            else if (textBox5.Text == "")
            {
                MessageBox.Show("Please enter your  location");
                textBox5.Focus();
            }
            else
            {
                string hhhh = textBox1.Text.Trim();
                textBox1.Text = hhhh;

                hhhh = textBox3.Text.Trim();
                textBox3.Text = hhhh;
                hhhh = textBox2.Text.Trim();
                textBox2.Text = hhhh;
                hhhh = textBox4.Text.Trim();
                textBox4.Text = hhhh;
                hhhh = textBox5.Text.Trim();
                textBox5.Text = hhhh;

                suplier employee = new suplier();
                employee.sup_name = textBox1.Text + " " + textBox3.Text;
                employee.sup_number =Convert.ToInt32( textBox2.Text);
                employee.email = textBox4.Text;
                employee.location = textBox5.Text;
               
                suplier.addTo(employee);
                MessageBox.Show("Done");
            }

        }
    }
}
