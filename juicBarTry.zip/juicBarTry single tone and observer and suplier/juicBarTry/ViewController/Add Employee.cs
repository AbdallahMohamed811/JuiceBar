﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using new_object;
using juicBarTry;
namespace OOSE_GUI
{
    public partial class Add_Employee : Form
    {
        public Add_Employee()
        {
            InitializeComponent();
        }

        private void Add_Employee_Load(object sender, EventArgs e)
        {
            fill();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter your  first name");
                textBox1.Focus();
            }

            else if (textBox3.Text == "")
            {
                MessageBox.Show("Please enter your last name");
                textBox3.Focus();
            }


            else if (textBox2.Text == "")
            {
                MessageBox.Show("Please enter your  salary");
                textBox3.Focus();
            }
            else
            {
                string hhhh = textBox1.Text.Trim();
                textBox1.Text = hhhh;

                hhhh = textBox3.Text.Trim();
                textBox3.Text = hhhh;
                hhhh = textBox2.Text.Trim();
                textBox2.Text = hhhh;

                emp employee = new emp();
                employee.EmpName = textBox1.Text + " " + textBox3.Text;
                employee.EmpSalary = textBox2.Text;
                employee.roleID = Convert.ToInt32(comboBox1.SelectedValue);
                if (employee.roleID == 2 || employee.roleID == 3)
                {
                    User.addTo(textBox1.Text, "admin");
                    employee.UserId = User.selectAll()[User.selectAll().Count - 1].id;
                }
                emp.addTo(employee);
                MessageBox.Show("Done");
            }
        }

       private void fill()
       {
            comboBox1.DataSource = role.selectAll();
            comboBox1.DisplayMember = "rolename";
            comboBox1.ValueMember = "roleid";
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
       (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }
    }
}
