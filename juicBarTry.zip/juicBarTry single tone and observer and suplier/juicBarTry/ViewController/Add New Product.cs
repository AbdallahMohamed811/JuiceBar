﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using juicBarTry;
using new_object;
using jucie;

namespace OOSE_GUI
{
    public partial class Add_New_Product : Form
    {
        public Add_New_Product()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter your   name");
                textBox1.Focus();
            }

            else if (textBox3.Text == "")
            {
                MessageBox.Show("Please enter your  price");
                textBox3.Focus();
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("Please enter your   wholeprice");
                textBox2.Focus();
            }

            else if (textBox4.Text == "")
            {
                MessageBox.Show("Please enter your  quantity");
                textBox4.Focus();
            }
            else
            {
                string hhhh = textBox1.Text.Trim();
                textBox1.Text = hhhh;

                hhhh = textBox3.Text.Trim();
                textBox3.Text = hhhh;
                hhhh = textBox2.Text.Trim();
                textBox2.Text = hhhh;
                hhhh = textBox4.Text.Trim();
                textBox4.Text = hhhh;

                Product pro = new Product();
                pro.ADD_pro(textBox1.Text, Convert.ToInt32(textBox3.Text), Convert.ToInt32(comboBox1.SelectedValue), Convert.ToInt32(textBox4.Text), Convert.ToInt32(textBox2.Text));
                textBox3.Text = "";
                textBox1.Text = "";
                textBox4.Text = "";
                textBox2.Text = "";
                MessageBox.Show("dn");
            }
        }

        private void Add_New_Product_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource = category.selectAll();
            comboBox1.DisplayMember = "catName";
            comboBox1.ValueMember = "catID";
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
      (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }
    }
}
