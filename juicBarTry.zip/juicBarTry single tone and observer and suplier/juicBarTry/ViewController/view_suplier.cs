﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DGVPrinterHelper;
using juicBarTry;
using juicBarTry.Model;

namespace juicBarTry.ViewController
{
    public partial class view_suplier : Form
    {
        int curentRow = -1;
        public view_suplier()
        {
            InitializeComponent();
            this.Load += View_suplier_Load;
        }

        private void View_suplier_Load(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            dataGridView1.CellClick += dataGridView1_CellClick;
            fill();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            suplier_add suplier_ad = new suplier_add();
            suplier_ad.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter your   name");
                textBox1.Focus();
            }

            else if (textBox3.Text == "")
            {
                MessageBox.Show("Please enter your  number");
                textBox3.Focus();
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("Please enter your  email");
                textBox2.Focus();
            }
            else if (textBox4.Text == "")
            {
                MessageBox.Show("Please enter your  location");
                textBox3.Focus();
            }
            else
            {
                string hhhh = textBox1.Text.Trim();
                textBox1.Text = hhhh;

                hhhh = textBox3.Text.Trim();
                textBox3.Text = hhhh;
                hhhh = textBox2.Text.Trim();
                textBox2.Text = hhhh;
                hhhh = textBox4.Text.Trim();
                textBox4.Text = hhhh;

                int id = Convert.ToInt32(dataGridView1.Rows[curentRow].Cells["sup_id"].Value);
                suplier employ = new suplier();
                employ.selectWithId(id);
                employ.sup_name = textBox1.Text;

                employ.sup_number = Convert.ToInt32(textBox3.Text);
                employ.email = textBox2.Text;

                employ.location = textBox4.Text;
                suplier.update(employ);
                fill();
            }


        }

        void fill()
        {
            BindingSource bindingSource1 = new BindingSource();
            foreach (var i in suplier.selectAll())
            {
                bindingSource1.Add(i);
            }
            dataGridView1.DataSource = bindingSource1;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            curentRow = dataGridView1.CurrentCell.RowIndex;
            textBox1.Text = dataGridView1.Rows[curentRow].Cells["sup_name"].Value.ToString();
            textBox3.Text = dataGridView1.Rows[curentRow].Cells["sup_number"].Value.ToString();
            textBox4.Text = dataGridView1.Rows[curentRow].Cells["location"].Value.ToString();
            textBox2.Text = dataGridView1.Rows[curentRow].Cells["email"].Value.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            suplier.deleteWithID(Convert.ToInt32(dataGridView1.Rows[curentRow].Cells["sup_id"].Value));
            fill();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            DGVPrinter printer = new DGVPrinter(); printer.Title = "Category Report";
            printer.SubTitle = "Category"; printer.SubTitleFormatFlags = StringFormatFlags.LineLimit |
            StringFormatFlags.NoClip; printer.PageNumbers = true;
            printer.PageNumberInHeader = false;
            printer.ColumnWidth = DGVPrinter.ColumnWidthSetting.Porportional; printer.HeaderCellAlignment = StringAlignment.Near; printer.Footer = "Your Company Name Here";
            printer.FooterSpacing = 15;

            printer.PrintDataGridView(dataGridView1);

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
       (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }
    }
}
